<template>
    <button class=" bg-secondColor">
        <slot></slot>
    </button>
</template>