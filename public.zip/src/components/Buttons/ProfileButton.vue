<template>
    <button class="py-2 w-40 font-bold text-sm rounded"><slot></slot></button>
</template>