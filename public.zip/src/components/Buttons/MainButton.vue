<template>
    <button class="py-2 bg-mainColor">
        <slot></slot>
    </button>
</template>